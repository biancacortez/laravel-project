
<?php $__env->startSection('title'); ?>
	Event Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container mt-5">
		<center><div class="card bg-light" style="width: 20rem;">
			<div class="card-body">
		<h3>Schedule: <?php echo e($event->schedule); ?></h3><br>
		<h3>Venue: <?php echo e($event->venue); ?></h3><br>
		<h3>In Charge: <?php echo e($event->in_charge); ?></h3><br>
		

	<a href="<?php echo e(route('events.index')); ?>" class="btn btn-success">Back</a>
			</div>
		</div></center>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel App\FinalProject\resources\views/pages/event.blade.php ENDPATH**/ ?>