
<?php $__env->startSection('title'); ?>
	My Events
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

	<div class="container mt-4">
		<h5>Event Management System</h5>
				<a href="<?php echo e(route('events.create')); ?>"><i class="fa fa-plus-circle mb-4 mt-4" style="font-size:36px;"></i></a>
		<div class="row mt-3">
			<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="col-6 col-md-4 mb-3">
				<div class="card-rounded-3" style="width: 17rem;">
					<div class="card-body bg-info">
						<div class="d-grid gap-2 d-md-flex justify-content-md-end">
							<form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST">
							<?php echo method_field('DELETE'); ?>
							<?php echo csrf_field(); ?>													
							<button aria-label= "Close" class="fa fa-times mb-5 bg-light" style= "font-size:15px;" onclick="return confirm('Are you sure you want to delete?')"></button>
							</form> 
						</div>

						<center><h5 class="mb-5"><?php echo e($event -> event_column); ?></h5></center>
						<center>
							<button class="btn btn-light mt-2"><a class="text-dark" href="<?php echo e(route('events.show', $event->id)); ?>">View</a></button>
							<button class="btn btn-light mt-2"><a class="text-dark" href="<?php echo e(route('events.edit', $event->id)); ?>">Edit</a></button>
						</center>
					</div>
					
				</div>
				
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel App\FinalProject\resources\views/pages/home.blade.php ENDPATH**/ ?>