
<?php $__env->startSection('title'); ?>
	Edit Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="col-md-8 offset-md-2">
			<h4>Edit Event</h4>

			<form action="<?php echo e(route('events.update', $event->id)); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo method_field('put'); ?>
				<div class="form-group">
					<label class="form-label">Event</label>
					<input type="text" value="<?php echo e($event -> event_column); ?>" class="form-control" name="event_input" placeholder="Enter event here" required>
					<input type="date" value="<?php echo e($event -> schedule); ?>" class="form-control" name="date_input" placeholder="Date" required>
					<input type="text" value="<?php echo e($event -> venue); ?>" class="form-control" name="venue_input" placeholder="Venue" required>
					<input type="text" value="<?php echo e($event-> in_charge); ?>" class="form-control" name="incharge_input" placeholder="In Charge" required>

					<input type="submit" value="Update" class=" mt-2 btn btn-success">
				</div>
				
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel App\FinalProject\resources\views/pages/edit.blade.php ENDPATH**/ ?>