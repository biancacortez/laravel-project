
<?php $__env->startSection('title'); ?>
	Add Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<center><div class="card bg-light" style="width: 20rem;">
			<div class="card-body">
		<div class="col-md-10">
			<h4>Add Event</h4>

			<form action="<?php echo e(route('events.store')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo method_field('post'); ?>
				<div class="form-group">

					Event Name: <input type="text" class="form-control" name="event_input" required>
					Date: <input type="date" class="form-control" name="date_input"required>
					Venue: <input type="text" class="form-control" name="venue_input" required>
					In Charge: <input type="text" class="form-control" name="incharge_input" required>

					<input type="submit" value="Add" class=" mt-2 btn btn-info">
					<a class=" mt-2 btn btn-info" href="<?php echo e(route('events.index')); ?>">Cancel</a>
				</div>
				
			</form>
		</div>
	</div>
	</div></center>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel App\FinalProject\resources\views/pages/add.blade.php ENDPATH**/ ?>