@extends('layout.master')
@section('title')
	Edit Event
@endsection
@section('content')
	<div class="container">
		<div class="col-md-8 offset-md-2">
			<h4>Edit Event</h4>

			<form action="{{route('events.update', $event->id)}}" method="post">
				@csrf
				@method('put')
				<div class="form-group">
					<label class="form-label">Event</label>
					<input type="text" value="{{$event -> event_column}}" class="form-control" name="event_input" placeholder="Enter event here" required>
					<input type="date" value="{{$event -> schedule}}" class="form-control" name="date_input" placeholder="Date" required>
					<input type="text" value="{{$event -> venue}}" class="form-control" name="venue_input" placeholder="Venue" required>
					<input type="text" value="{{$event-> in_charge}}" class="form-control" name="incharge_input" placeholder="In Charge" required>

					<input type="submit" value="Update" class=" mt-2 btn btn-success">
				</div>
				
			</form>
		</div>
	</div>
@endsection