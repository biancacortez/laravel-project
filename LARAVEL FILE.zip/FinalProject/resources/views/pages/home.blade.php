@extends('layout.master')
@section('title')
	My Events
@endsection
@section('content')

	<div class="container mt-4">
		<h5>Event Management System</h5>
				<a href="{{route('events.create')}}"><i class="fa fa-plus-circle mb-4 mt-4" style="font-size:36px;"></i></a>
		<div class="row mt-3">
			@foreach ($events as $event)

			<div class="col-6 col-md-4 mb-3">
				<div class="card-rounded-3" style="width: 17rem;">
					<div class="card-body bg-info">
						<div class="d-grid gap-2 d-md-flex justify-content-md-end">
							<form action="{{route('events.destroy', $event->id)}}" method="POST">
							@method('DELETE')
							@csrf													
							<button aria-label= "Close" class="fa fa-times mb-5 bg-light" style= "font-size:15px;" onclick="return confirm('Are you sure you want to delete?')"></button>
							</form> 
						</div>

						<center><h5 class="mb-5">{{$event -> event_column}}</h5></center>
						<center>
							<button class="btn btn-light mt-2"><a class="text-dark" href="{{route('events.show', $event->id)}}">View</a></button>
							<button class="btn btn-light mt-2"><a class="text-dark" href="{{route('events.edit', $event->id)}}">Edit</a></button>
						</center>
					</div>
					
				</div>
				
			</div>
			@endforeach
			
		</div>
	</div>
@endsection