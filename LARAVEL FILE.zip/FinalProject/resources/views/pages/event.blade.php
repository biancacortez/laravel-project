@extends('layout.master')
@section('title')
	Event Details
@endsection
@section('content')
	<div class="container mt-5">
		<center><div class="card bg-light" style="width: 20rem;">
			<div class="card-body">
		<h3>Schedule: {{$event->schedule}}</h3><br>
		<h3>Venue: {{$event->venue}}</h3><br>
		<h3>In Charge: {{$event->in_charge}}</h3><br>
		

	<a href="{{route('events.index')}}" class="btn btn-success">Back</a>
			</div>
		</div></center>
	</div>
@endsection